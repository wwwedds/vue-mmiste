<template>
  <div class='footer-guide'>
  <span class="guide-item " :class="{on: $route.path ==='/msite'}" @click="goto('/msite')">
    <span>
      <i class="iconfont icon-waimai"></i>
    </span>
    <span>外卖</span>
  </span>
  <span class="guide-item" :class="{on: $route.path ==='/search'}" @click="goto('/search')">
    <span>
      <i class="iconfont icon-search"></i>
    </span>
    <span>搜索</span>
  </span>
  <span class="guide-item" :class="{on: $route.path ==='/order'}" @click="goto('/order')">
    <span>
      <i class="iconfont icon-dingdan"></i>
    </span>
    <span>订单</span>
  </span>
  <span class="guide-item" :class="{on: $route.path ==='/profile'}"  @click="goto('/profile')">
    <span>
      <i class="iconfont icon-geren"></i>
    </span>
    <span>我的</span>
  </span>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
methods: {
  goto(path){
    this.$router.replace(path)
  }
},
  }
</script>
<style lang="stylus" rel="stylesheet/stylus" scoped>
  @import '../../common/stylus/mixins.styl'
  .footer-guide
    top-border-1px(#cccccc)
    display flex
    position fixed
    left 0
    bottom 0
    height 50px
    width 100%
    background #fff
    .guide-item
      display flex
      flex-direction column
      text-align center
      width 25%
      &.on
        color green
      span
        margin-top 3px
        font-size 12px
        i
          font-size 22px
</style>
